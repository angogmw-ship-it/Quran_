package com.hesham.tasmeeq.ui

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.hesham.tasmeeq.domain.*
import com.hesham.tasmeeq.ui.recitation.RecitationRecognizer
import kotlinx.coroutines.launch

@Composable
fun HomeScreen(nav:NavHostController, vm:AppViewModel) {
    val st by vm.state.collectAsState()
    val cards = listOf(
        "ابدأ التسميع" to "recite",
        "مراجعة الحفظ" to "recite",
        "المصحف" to "mushaf",
        "آخر جلسة" to "recite",
        "إحصائياتي" to "stats",
        "الإعدادات" to "settings"
    )
    Scaffold { p ->
        Column(Modifier.fillMaxSize().padding(p).padding(20.dp), horizontalAlignment=Alignment.CenterHorizontally) {
            Text("تسميع القرآن", style=MaterialTheme.typography.headlineLarge)
            Text("صانع التطبيق: هشام عبدالقوي", style=MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(24.dp))
            if (st.loading) CircularProgressIndicator()
            cards.forEach { (title, route) ->
                Button(onClick={nav.navigate(route)}, Modifier.fillMaxWidth().padding(vertical=6.dp)) { Text(title) }
            }
            if (!st.loaded && !st.loading)
                Text("تعذر تحميل قاعدة القرآن. افتح الإنترنت مرة واحدة لإتمام المزامنة ثم سيعمل التطبيق دون اتصال.", textAlign=TextAlign.Center)
        }
    }
}

@Composable
fun SurahPicker(nav:NavHostController, vm:AppViewModel) {
    val st by vm.state.collectAsState()
    var query by remember { mutableStateOf("") }
    val filtered = surahs.filter { it.name.contains(query) || it.number.toString()==query }
    Scaffold(topBar={TopAppBar(title={Text("اختيار السورة")})}) { p ->
        Column(Modifier.padding(p).padding(16.dp)) {
            OutlinedTextField(query,{query=it},Modifier.fillMaxWidth(),label={Text("بحث")})
            Spacer(Modifier.height(8.dp))
            LazyColumn {
                items(filtered) { s ->
                    ListItem(
                        headlineContent={Text("${s.number}. ${s.name}")},
                        supportingContent={Text("${s.ayahs} آية")},
                        modifier=Modifier.fillMaxWidth(),
                        leadingContent={Text(s.number.toString())},
                        trailingContent={Button(onClick={vm.setSurah(s.number);nav.navigate("recite")}){Text("اختيار")}}
                    )
                }
            }
        }
    }
}

@Composable
fun ReciteScreen(nav:NavHostController, vm:AppViewModel) {
    val st by vm.state.collectAsState()
    var ayahs by remember { mutableStateOf(emptyList<com.hesham.tasmeeq.data.AyahEntity>()) }
    var current by remember { mutableIntStateOf(st.startAyah) }
    var revealed by remember { mutableStateOf(setOf<Int>()) }
    var wrong by remember { mutableStateOf(setOf<Int>()) }
    var message by remember { mutableStateOf("") }
    val scope=rememberCoroutineScope()
    val context=androidx.compose.ui.platform.LocalContext.current
    val recognizer=remember { RecitationRecognizer(context) }
    val listening by recognizer.listening.collectAsState()
    val transcript by recognizer.text.collectAsState()
    val launcher=rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) recognizer.start{message=it} else message="يحتاج التطبيق إذن الميكروفون للتسميع."
    }

    LaunchedEffect(st.selectedSurah) { ayahs=vm.surah(st.selectedSurah) }
    LaunchedEffect(transcript) {
        if (transcript.isNotBlank() && ayahs.isNotEmpty()) {
            val words=TextMatcher.words(ayahs.firstOrNull{it.ayah==current}?.text.orEmpty())
            val spoken=TextMatcher.words(transcript)
            var idx=revealed.size
            if (idx < words.size) {
                val candidate=spoken.lastOrNull().orEmpty()
                val sim=TextMatcher.similarity(candidate,words[idx])
                if (sim >= 0.72) {
                    revealed = revealed + idx
                    message="ممتاز"
                } else if (candidate.isNotBlank()) {
                    wrong = wrong + idx
                    message="حاول مرة أخرى"
                }
            }
        }
    }

    DisposableEffect(Unit){ onDispose{recognizer.stop()} }

    Scaffold(topBar={
        TopAppBar(title={Text(surahs.first{it.number==st.selectedSurah}.name)}, navigationIcon={
            IconButton({nav.popBackStack()}){Icon(Icons.Default.ArrowBack,"رجوع")}
        })
    }) { p ->
        Column(Modifier.fillMaxSize().padding(p).padding(16.dp)) {
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){
                Text("الآية $current")
                Text("${revealed.size} / ${TextMatcher.words(ayahs.firstOrNull{it.ayah==current}?.text.orEmpty()).size}")
            }
            LinearProgressIndicator(
                progress={ if (TextMatcher.words(ayahs.firstOrNull{it.ayah==current}?.text.orEmpty()).isEmpty()) 0f
                else revealed.size.toFloat()/TextMatcher.words(ayahs.first{it.ayah==current}.text).size},
                Modifier.fillMaxWidth().padding(vertical=10.dp)
            )
            Card(Modifier.fillMaxWidth().weight(1f)) {
                val words=TextMatcher.words(ayahs.firstOrNull{it.ayah==current}?.text.orEmpty())
                Row(Modifier.fillMaxWidth().padding(22.dp),horizontalArrangement=Arrangement.End) {
                    words.forEachIndexed { i,w ->
                        val visible = i in revealed || (st.hiddenPercent < 100 && i < words.size * (100-st.hiddenPercent)/100)
                        Text(if (visible) "$w " else "▉ ", style=MaterialTheme.typography.headlineSmall,
                            color=if (i in wrong) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface)
                    }
                }
            }
            if (message.isNotBlank()) Text(message,Modifier.fillMaxWidth().padding(8.dp),textAlign=TextAlign.Center)
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceEvenly) {
                FilledTonalButton(onClick={
                    if (context.checkSelfPermission(Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED)
                        recognizer.start{message=it} else launcher.launch(Manifest.permission.RECORD_AUDIO)
                }) { Icon(Icons.Default.Mic,null); Spacer(Modifier.width(5.dp)); Text(if(listening)"جاري الاستماع" else "ابدأ") }
                FilledTonalButton(onClick={recognizer.stop();message="تم الإيقاف"}) { Icon(Icons.Default.Pause,null); Text("إيقاف") }
                FilledTonalButton(onClick={revealed=emptySet();wrong=emptySet();message=""}) { Icon(Icons.Default.Refresh,null); Text("إعادة") }
            }
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) {
                TextButton(onClick={if(current>1){current--;revealed=emptySet();wrong=emptySet()}}){Text("السابقة")}
                TextButton(onClick={if(current<ayahs.size){current++;revealed=emptySet();wrong=emptySet()}else message="انتهت السورة"}){Text("التالية")}
            }
        }
    }
}

@Composable
fun StatsScreen(nav:NavHostController, vm:AppViewModel) {
    val count by vm.sessionCount.collectAsState(0)
    val reviewed by vm.reviewed.collectAsState(0)
    val mistakes by vm.mistakes.collectAsState(0)
    val accuracy by vm.accuracy.collectAsState(0.0)
    Scaffold(topBar={TopAppBar(title={Text("إحصائياتي")})}) { p ->
        Column(Modifier.padding(p).padding(20.dp)) {
            Text("الجلسات: $count",style=MaterialTheme.typography.titleLarge)
            Text("الآيات المراجعة: $reviewed")
            Text("نسبة الدقة: ${"%.1f".format(accuracy)}%")
            Text("عدد الأخطاء: $mistakes")
            Spacer(Modifier.height(24.dp))
            Button(onClick={vm.clearStats()},Modifier.fillMaxWidth()){Text("إعادة ضبط الإحصائيات")}
        }
    }
}

@Composable
fun SettingsScreen(nav:NavHostController, vm:AppViewModel) {
    val st by vm.state.collectAsState()
    Scaffold(topBar={TopAppBar(title={Text("الإعدادات")})}) { p ->
        Column(Modifier.padding(p).padding(20.dp)) {
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){
                Text("الوضع الليلي"); Switch(st.darkMode,vm::setDark)
            }
            Text("مستوى الإخفاء: ${st.hiddenPercent}%")
            Slider(value=st.hiddenPercent.toFloat(),onValueChange={vm.setHidden((it/25).toInt()*25)},valueRange=0f..100f,steps=3)
            Text("حجم الخط: ${st.fontSize}")
            Slider(value=st.fontSize.toFloat(),onValueChange={vm.setFont(it.toInt())},valueRange=20f..40f,steps=19)
            HorizontalDivider(Modifier.padding(vertical=12.dp))
            Text("عن التطبيق",style=MaterialTheme.typography.titleLarge)
            Text("تسميع القرآن\nصانع التطبيق: هشام عبدالقوي\nنسخة 1.0.0")
            Spacer(Modifier.height(12.dp))
            Text("مصدر النص القرآني: Tanzil Project / Al Quran Cloud. يجب الحفاظ على نسبة المصدر وشروط الاستخدام.")
        }
    }
}

@Composable
fun MushafScreen(nav:NavHostController, vm:AppViewModel) {
    val st by vm.state.collectAsState()
    var text by remember { mutableStateOf("اختر سورة لعرض المصحف") }
    Scaffold(topBar={TopAppBar(title={Text("المصحف")})}) { p ->
        Column(Modifier.padding(p).padding(16.dp)) {
            Button({nav.navigate("surahs")},Modifier.fillMaxWidth()){Text("اختيار السورة")}
            Spacer(Modifier.height(12.dp))
            Text(text,style=MaterialTheme.typography.bodyLarge)
        }
    }
}
