package com.hesham.tasmeeq.domain

import java.text.Normalizer

object TextMatcher {
    private val diacritics = Regex("[\\u064B-\\u065F\\u0670\\u06D6-\\u06ED\\u0640]")
    fun normalize(s: String): String =
        Normalizer.normalize(s, Normalizer.Form.NFD)
            .replace(diacritics, "")
            .replace("أ","ا").replace("إ","ا").replace("آ","ا")
            .replace("ى","ي").replace("ة","ه")
            .replace(Regex("[^\\p{L}\\p{Nd}\\s]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()

    fun words(s: String): List<String> = normalize(s).split(" ").filter { it.isNotBlank() }

    fun similarity(a: String, b: String): Double {
        val x = normalize(a)
        val y = normalize(b)
        if (x == y) return 1.0
        if (x.isEmpty() || y.isEmpty()) return 0.0
        val dist = levenshtein(x, y)
        return 1.0 - dist.toDouble() / maxOf(x.length, y.length)
    }

    private fun levenshtein(a: String, b: String): Int {
        val d = Array(a.length + 1) { IntArray(b.length + 1) }
        for (i in 0..a.length) d[i][0] = i
        for (j in 0..b.length) d[0][j] = j
        for (i in 1..a.length) for (j in 1..b.length) {
            d[i][j] = minOf(
                d[i-1][j] + 1, d[i][j-1] + 1,
                d[i-1][j-1] + if (a[i-1] == b[j-1]) 0 else 1
            )
        }
        return d[a.length][b.length]
    }
}
