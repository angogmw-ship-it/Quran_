package com.hesham.tasmeeq.ui.recitation

import android.content.*
import android.os.Bundle
import android.speech.*
import android.speech.SpeechRecognizer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

class RecitationRecognizer(private val context: Context) {
    private var recognizer: SpeechRecognizer? = null
    private val _text = MutableStateFlow("")
    val text = _text.asStateFlow()
    private val _listening = MutableStateFlow(false)
    val listening = _listening.asStateFlow()

    fun start(onError:(String)->Unit = {}) {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            onError("خدمة التعرف على الكلام غير متاحة على هذا الجهاز")
            return
        }
        stop()
        recognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
            setRecognitionListener(object: RecognitionListener {
                override fun onResults(results: Bundle) {
                    val r = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    _text.value = r?.firstOrNull().orEmpty()
                    _listening.value = false
                }
                override fun onError(error: Int) {
                    _listening.value = false
                    onError(errorMessage(error))
                }
                override fun onReadyForSpeech(p0: Bundle?) { _listening.value = true }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(p0: Float) {}
                override fun onBufferReceived(p0: ByteArray?) {}
                override fun onEndOfSpeech() { _listening.value = false }
                override fun onPartialResults(p0: Bundle?) {}
                override fun onEvent(p0: Int, p1: Bundle?) {}
            })
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "ar")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            }
            startListening(intent)
        }
    }

    fun stop() { recognizer?.destroy(); recognizer=null; _listening.value=false }
    private fun errorMessage(code:Int) = when(code) {
        SpeechRecognizer.ERROR_NO_MATCH -> "لم يتضح الصوت. حاول القراءة بوضوح."
        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "لم يتم التقاط قراءة. حاول مرة أخرى."
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "لم يتم منح إذن الميكروفون."
        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "التعرف يحتاج إلى خدمة الكلام المتاحة على الجهاز."
        else -> "حدث خطأ في التعرف على التلاوة."
    }
}
