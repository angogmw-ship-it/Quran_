package com.hesham.tasmeeq.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "ayahs", primaryKeys = ["surah", "ayah"])
data class AyahEntity(
    val surah: Int,
    val ayah: Int,
    val text: String,
    val page: Int = 0
)

@Entity(tableName = "sessions")
data class SessionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val surah: Int,
    val startAyah: Int,
    val endAyah: Int,
    val accuracy: Int,
    val mistakes: Int,
    val durationSeconds: Long,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "settings")
data class SettingEntity(
    @PrimaryKey val key: String,
    val value: String
)

@Dao
interface QuranDao {
    @Query("SELECT * FROM ayahs WHERE surah = :surah ORDER BY ayah")
    suspend fun ayahs(surah: Int): List<AyahEntity>

    @Query("SELECT * FROM ayahs WHERE surah = :surah AND ayah BETWEEN :from AND :to ORDER BY ayah")
    suspend fun range(surah: Int, from: Int, to: Int): List<AyahEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(items: List<AyahEntity>)

    @Query("SELECT COUNT(*) FROM ayahs")
    suspend fun count(): Int
}

@Dao
interface SessionDao {
    @Insert suspend fun insert(item: SessionEntity)
    @Query("SELECT * FROM sessions ORDER BY createdAt DESC LIMIT 30")
    fun recent(): Flow<List<SessionEntity>>
    @Query("SELECT COUNT(*) FROM sessions") fun count(): Flow<Int>
    @Query("SELECT COALESCE(SUM(endAyah-startAyah+1),0) FROM sessions") fun reviewed(): Flow<Int>
    @Query("SELECT COALESCE(SUM(mistakes),0) FROM sessions") fun mistakes(): Flow<Int>
    @Query("SELECT COALESCE(AVG(accuracy),0) FROM sessions") fun accuracy(): Flow<Double>
    @Query("DELETE FROM sessions") suspend fun clear()
}

@Dao
interface SettingsDao {
    @Query("SELECT value FROM settings WHERE `key`=:key")
    suspend fun get(key: String): String?
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun put(item: SettingEntity)
}

@Database(entities = [AyahEntity::class, SessionEntity::class, SettingEntity::class], version = 1)
abstract class QuranDatabase : RoomDatabase() {
    abstract fun quran(): QuranDao
    abstract fun sessions(): SessionDao
    abstract fun settings(): SettingsDao

    companion object {
        @Volatile private var INSTANCE: QuranDatabase? = null
        fun get(context: android.content.Context): QuranDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    QuranDatabase::class.java,
                    "tasmee_quran.db"
                ).build().also { INSTANCE = it }
            }
    }
}
