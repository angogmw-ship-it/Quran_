package com.hesham.tasmeeq

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.material3.*
import androidx.compose.runtime.getValue
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.*
import com.hesham.tasmeeq.ui.*

class MainActivity: ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val vm: AppViewModel = viewModel()
            val st by vm.state.collectAsState()
            MaterialTheme(colorScheme=if(st.darkMode) darkColorScheme() else lightColorScheme()) {
                val nav=rememberNavController()
                NavHost(navController=nav,startDestination="home") {
                    composable("home"){HomeScreen(nav,vm)}
                    composable("surahs"){SurahPicker(nav,vm)}
                    composable("recite"){ReciteScreen(nav,vm)}
                    composable("mushaf"){MushafScreen(nav,vm)}
                    composable("stats"){StatsScreen(nav,vm)}
                    composable("settings"){SettingsScreen(nav,vm)}
                }
            }
        }
    }
}
