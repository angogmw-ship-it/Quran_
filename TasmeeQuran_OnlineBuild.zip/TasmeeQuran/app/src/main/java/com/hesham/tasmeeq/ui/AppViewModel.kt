package com.hesham.tasmeeq.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.hesham.tasmeeq.data.*
import com.hesham.tasmeeq.domain.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class AppState(
    val loaded = false,
    val loading = false,
    val selectedSurah = 1,
    val startAyah = 1,
    val hiddenPercent = 100,
    val darkMode = false,
    val fontSize = 26
)

class AppViewModel(app: Application): AndroidViewModel(app) {
    private val db = QuranDatabase.get(app)
    private val repo = QuranRepository(db)
    private val _state = MutableStateFlow(AppState())
    val state = _state.asStateFlow()

    val sessions = db.sessions().recent()
    val sessionCount = db.sessions().count()
    val reviewed = db.sessions().reviewed()
    val mistakes = db.sessions().mistakes()
    val accuracy = db.sessions().accuracy()

    init { load() }

    private fun load() = viewModelScope.launch {
        _state.update { it.copy(loading=true) }
        val ok = repo.ensureQuranLoaded()
        val dark = db.settings().get("dark") == "true"
        val hidden = db.settings().get("hidden")?.toIntOrNull() ?: 100
        val font = db.settings().get("font")?.toIntOrNull() ?: 26
        _state.update { it.copy(loaded=ok || db.quran().count()>0, loading=false, darkMode=dark, hiddenPercent=hidden, fontSize=font) }
    }

    fun setSurah(n:Int) { _state.update { it.copy(selectedSurah=n, startAyah=1) } }
    fun setStartAyah(n:Int) { _state.update { it.copy(startAyah=n) } }
    fun setHidden(n:Int) { _state.update { it.copy(hiddenPercent=n) }; save("hidden", n.toString()) }
    fun setDark(v:Boolean) { _state.update { it.copy(darkMode=v) }; save("dark", v.toString()) }
    fun setFont(v:Int) { _state.update { it.copy(fontSize=v) }; save("font", v.toString()) }
    fun saveLast(s:Int,a:Int) { save("lastSurah",s.toString()); save("lastAyah",a.toString()) }

    private fun save(k:String,v:String) = viewModelScope.launch { db.settings().put(SettingEntity(k,v)) }
    suspend fun range(s:Int,f:Int,t:Int) = repo.range(s,f,t)
    suspend fun surah(s:Int) = repo.surah(s)
    fun addSession(item:SessionEntity) = viewModelScope.launch { db.sessions().insert(item) }
    fun clearStats() = viewModelScope.launch { db.sessions().clear() }
}
