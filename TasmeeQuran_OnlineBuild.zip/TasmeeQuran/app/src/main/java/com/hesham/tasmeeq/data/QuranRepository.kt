package com.hesham.tasmeeq.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject

class QuranRepository(private val db: QuranDatabase) {
    private val client = OkHttpClient()

    suspend fun ensureQuranLoaded(): Boolean = withContext(Dispatchers.IO) {
        if (db.quran().count() > 6000) return@withContext true
        val request = Request.Builder()
            .url("https://api.alquran.cloud/v1/quran/quran-uthmani")
            .build()
        runCatching {
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) error("HTTP ${response.code}")
                val root = JSONObject(response.body!!.string())
                val surahs = root.getJSONObject("data").getJSONArray("surahs")
                val result = mutableListOf<AyahEntity>()
                for (i in 0 until surahs.length()) {
                    val s = surahs.getJSONObject(i)
                    val surahNo = s.getInt("number")
                    val ayahs = s.getJSONArray("ayahs")
                    for (j in 0 until ayahs.length()) {
                        val a = ayahs.getJSONObject(j)
                        result += AyahEntity(
                            surah = surahNo,
                            ayah = a.getInt("numberInSurah"),
                            text = a.getString("text"),
                            page = a.optInt("page", 0)
                        )
                    }
                }
                db.quran().insertAll(result)
            }
        }.isSuccess
    }

    suspend fun range(surah: Int, from: Int, to: Int) = db.quran().range(surah, from, to)
    suspend fun surah(surah: Int) = db.quran().ayahs(surah)
}
